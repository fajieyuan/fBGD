1. Item Ratings (ratings.txt): [user-id, item-id, rating-value]

2. Trust Ratings (trust.txt):  [user-id (trustor), user-id (trustee), trust-value]

The trust links are directed. 

3. To use this data set in your research, please consider to cite our work: 

@INPROCEEDINGS{guo2013novel,
  author = {Guo, G. and Zhang, J. and Yorke-Smith, N.},
  title = {A Novel Bayesian Similarity Measure for Recommender Systems},
  booktitle = {Proceedings of the 23rd International Joint Conference on Artificial Intelligence (IJCAI)},
  year = {2013},
  pages = {2619-2625}
}


Copy Right 2013
Guibing Guo
guoguibing@gmail.com